# Review guide: SmartAttend

## One-line summary
A web-based class register where a teacher marks Present, Absent or Leave with one click, sees each
student's attendance percentage instantly, and gets a warning when a student falls below the minimum.

## Problem it solves
Paper registers are slow to total up, easy to get wrong, and defaulters are noticed late.
SmartAttend calculates percentages live and flags students below the required limit (default 75%).

## 5-minute demo (in this order)
0. **Log in as the teacher first** (`teacher / teacher123`). Open a course tab that meets today and
   click **Start attendance session**. Point out the 6-digit code and the countdown.
1. **In a second browser tab (or another device), log in as a student** - roll `CS01`, password
   `cs01`. Show that the class asks for today's code. Type the wrong code first (rejected), then the
   real code (accepted, marked Present). Point out the class not held today shows "No class today",
   and a class where the teacher hasn't started a session yet shows "Waiting for the teacher".
2. **Switch back to the teacher tab** and show the student's box now has a blue outline, meaning they
   checked themselves in. Explain a teacher's own click always overrides that. Point out the top line (today's counts) and the red warning naming the low students.
2. **Mark today's class.** Click today's date to mark everyone present, then click two students to make them Absent and Leave.
3. **Show live results.** The percentages, the bar behind each name and the summary line change immediately.
4. **Open a report card.** Click a low-attendance student's name and show the per-course table.
5. **Change the minimum** to 90 and show more students turning red.
6. **Switch course and month.** Each course has its own class days.
7. **Add a student**, then search for them.
8. **Export CSV and Print report.** Say the register can be shared or filed.
9. **Backup and Restore.** Say the data is stored in the browser and can be moved between computers.

## Features to list on your slide
- Student login and self check-in, gated by a teacher-issued attendance code (and an optional GPS proximity check), separate from the teacher's login
- One-click marking with three statuses (Present, Absent, Leave)
- Mark a whole class present in one click
- Live percentage per student, with warning colours below the minimum
- Course-wise and month-wise views, with each course's own timetable days
- Student report card, course summary, search
- Add and remove students
- CSV export, printable report, JSON backup and restore
- Works offline, no install, dark mode, keyboard accessible

## Technology (say it in this order)
- **HTML** builds the page structure.
- **CSS** styles it, using variables for colours so dark mode is one small block.
- **JavaScript** holds the data in an object, calculates percentages, draws the register table,
  and saves to the browser's `localStorage` after every change.

## Likely questions and answers
0. **How does student authentication work?** Each student has a roll number and a password, checked
   against a students list held in the browser. A student can only see and mark their own attendance,
   and only for today's classes; the teacher's login is separate and can see and edit everyone.
0b. **How do you stop a student marking attendance from home?** Two layers. First, self check-in only
   works while the teacher has an open attendance session for that class, and needs the 6-digit code
   the teacher displays in the room that session - a student at home doesn't have it. Second, an
   optional location check compares the student's device GPS to a saved campus location and a radius,
   using the Haversine distance formula; a student outside that radius is refused even with the
   correct code.
0c. **Can't someone fake their GPS location?** Yes, on a browser-only project a determined student
   could spoof their device location, so the location check is a deterrent, not a guarantee - that's
   worth saying plainly if asked. The code is the stronger control, since it can only be learned by
   being in the room. A production system would also verify on a server (for example checking the
   request's IP is on the campus Wi-Fi, alongside the code), which is a natural next step to mention.
0d. **Is this secure enough for a real college?** Passwords are stored in plain text in the browser,
   which is fine for a demo but not production. A real deployment would check passwords and the
   attendance code on a server, with hashing, which is a natural next step.
1. **Where is the data stored?** In the browser's localStorage as JSON. It stays after a refresh.
2. **How is the percentage calculated?** (Present + Leave) divided by classes marked. Blank boxes are not counted.
3. **Why does Leave count as attended?** Approved leave is treated as excused, as many colleges do. It is one line to change.
4. **Why no future dates?** Attendance can only be recorded for classes that have happened.
5. **What if two teachers use it?** This version stores data per browser. A shared version needs a database and a server, which is the next step.
6. **How would you add a database?** Move the data functions to a backend API (for example FastAPI with SQLite or PostgreSQL) and call it with `fetch`.
7. **How do you stop wrong entries?** Boxes can be edited again, and the roll number must be unique.
8. **What are the limitations?** No real login and no multi-user sync yet. Be upfront: this is a front-end project, and you know how to extend it.
9. **What would you add next?** Login with roles, parent SMS or email alerts for defaulters, a database backend, and charts.
10. **How is it secure?** Text from users is escaped before it is shown, so pasted HTML cannot run.

## Tips for full marks
- Run through the demo twice before the review, and reset demo data first.
- Keep a printed report and the CSV file ready to show.
- Know where `render()`, `save()` and the percentage calculation are in `script.js` and be ready to open them.
- Add a title slide with the problem, features, technology, demo screenshots and future scope.
