// SmartAttend logic. Data is stored in the browser (localStorage) under the keys below.
// NOTE for reviewers: passwords are stored in plain text in the browser for this demo.
// That is fine for a local class project, but a real system must hash passwords on a server.
const $ = s => document.querySelector(s);
const pad = n => String(n).padStart(2, "0");
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const DAYNAME = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const KEY = "smartattend.register.v2", SESS_KEY = "smartattend.session";
const today = new Date(); today.setHours(0, 0, 0, 0);
const todayIso = iso(today);

function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function seed() {
  const names = ["Aarav Sharma","Diya Reddy","Rohan Verma","Sneha Iyer","Kiran Rao","Meera Nair","Arjun Singh","Isha Gupta","Vikram Patel","Anaya Khan"];
  const students = names.map((n, i) => ({id: i + 1, roll: "CS" + pad(i + 1), name: n, password: ("CS" + pad(i + 1)).toLowerCase()}));
  const courses = [
    {id: 1, code: "DBMS", name: "Database Systems", days: [1, 3, 5]},
    {id: 2, code: "API",  name: "Backend APIs",     days: [2, 4]},
    {id: 3, code: "WEB",  name: "Web Technologies", days: [1, 4, 6]}];
  const staff = [{username: "teacher", password: "teacher123", role: "teacher"}, {username: "admin", password: "admin123", role: "admin"}];
  const r = rng(7), marks = {}, selfMarked = {};
  for (let back = 1; back <= 75; back++) {
    const d = new Date(today); d.setDate(today.getDate() - back);
    for (const c of courses) if (c.days.includes(d.getDay())) for (const s of students) {
      const p = (s.id === 3 || s.id === 7) ? 0.55 : 0.9;
      marks[`${c.id}|${iso(d)}|${s.id}`] = r() < p ? "P" : (p < 0.6 ? "A" : (r() < 0.5 ? "A" : "L"));
    }
  }
  return {students, courses, staff, marks, selfMarked, threshold: 75, nextId: 11,
    sessions: {}, security: {requireLocation: false, campus: null, radius: 200}};
}
function load() { try { const x = localStorage.getItem(KEY); if (x) return JSON.parse(x); } catch (e) {} return seed(); }
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
function loadSession() { try { return JSON.parse(localStorage.getItem(SESS_KEY)); } catch (e) { return null; } }
function saveSession() { try { sess ? localStorage.setItem(SESS_KEY, JSON.stringify(sess)) : localStorage.removeItem(SESS_KEY); } catch (e) {} }

let S = load(), sess = loadSession();
let courseId = S.courses[0].id, month = todayIso.slice(0, 7), query = "", lastKey = null;
const course = () => S.courses.find(c => c.id === courseId);
const mk = (cid, dIso, sid) => `${cid}|${dIso}|${sid}`;
function say(t) { $("#live").textContent = t; }

// ---------------- attendance-session codes + optional location check ----------------
const SESS_MIN = 10;                                           // a code is valid for 10 minutes
function sessKey(cid, date) { return `${cid}|${date}`; }
function activeSession(cid, date) {
  const s = S.sessions[sessKey(cid, date)];
  return s && s.expires > Date.now() ? s : null;
}
function startSession(cid, date) {
  S.sessions[sessKey(cid, date)] = {code: String(Math.floor(100000 + Math.random() * 900000)), expires: Date.now() + SESS_MIN * 60000};
  save();
}
function stopSession(cid, date) { delete S.sessions[sessKey(cid, date)]; save(); }
function distMeters(a, b) {                                    // haversine formula, straight-line distance
  const R = 6371000, toRad = x => x * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat), dLng = toRad(b.lng - a.lng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

// ---------------- login / logout ----------------
$("#role-tabs").addEventListener("click", e => {
  const b = e.target.closest("[data-role]"); if (!b) return;
  [...$("#role-tabs").children].forEach(x => x.setAttribute("aria-selected", x === b));
  $("#student-login").hidden = b.dataset.role !== "student";
  $("#staff-login").hidden = b.dataset.role !== "staff";
  $("#lmsg").textContent = b.dataset.role === "student"
    ? "Student demo login: roll CS01, password cs01 (each student's password is their roll number in lowercase)."
    : "Staff demo login: teacher / teacher123, or admin / admin123 (only admin can remove students).";
});
$("#student-login").addEventListener("submit", e => {
  e.preventDefault();
  const roll = $("#s-roll").value.trim().toLowerCase(), pass = $("#s-pass").value;
  const s = S.students.find(x => x.roll.toLowerCase() === roll);
  if (!s || s.password !== pass) { $("#lmsg").textContent = "Roll number or password is incorrect."; return; }
  sess = {type: "student", id: s.id}; saveSession(); showApp();
});
$("#staff-login").addEventListener("submit", e => {
  e.preventDefault();
  const u = $("#t-user").value.trim(), p = $("#t-pass").value;
  const st = S.staff.find(x => x.username === u && x.password === p);
  if (!st) { $("#lmsg").textContent = "Username or password is incorrect."; return; }
  sess = {type: "staff", username: st.username, role: st.role}; saveSession(); showApp();
});
function logout() { sess = null; saveSession(); showApp(); }
$("#s-logout").addEventListener("click", logout);
$("#t-logout").addEventListener("click", logout);

function showApp() {
  $("#login").hidden = !!sess;
  $("#student-view").hidden = !(sess && sess.type === "student");
  $("#teacher-view").hidden = !(sess && sess.type === "staff");
  if (!sess) { $("#s-roll").value = ""; $("#s-pass").value = ""; return; }
  if (sess.type === "student") renderStudent(); else render();
}

// ---------------- student self check-in ----------------
function studentCourseStatus(s, c) {
  const held = c.days.includes(today.getDay());
  const k = mk(c.id, todayIso, s.id), v = S.marks[k];
  return {held, key: k, value: v};
}
function renderStudent() {
  const s = S.students.find(x => x.id === sess.id);
  if (!s) { logout(); return; }
  $("#s-who").textContent = `${s.name} - Roll ${s.roll}`;
  $("#s-date").textContent = today.toLocaleDateString(undefined, {weekday: "long", day: "numeric", month: "long"});

  $("#s-today").innerHTML = S.courses.map(c => {
    const {held, key, value} = studentCourseStatus(s, c);
    if (!held) return `<div class="chk"><div><b>${esc(c.code)}</b><span>${esc(c.name)}</span></div><span class="tag">No class today</span></div>`;
    if (value) {
      const label = {P: "Present", A: "Absent (marked by teacher)", L: "On leave"}[value];
      return `<div class="chk"><div><b>${esc(c.code)}</b><span>${esc(c.name)}</span></div><span class="tag ${value === "A" ? "bad" : "ok"}">${label}</span></div>`;
    }
    const open = activeSession(c.id, todayIso);
    if (!open) return `<div class="chk"><div><b>${esc(c.code)}</b><span>${esc(c.name)}, today</span></div><span class="tag">Waiting for the teacher to start check-in</span></div>`;
    return `<div class="chk wide"><div><b>${esc(c.code)}</b><span>${esc(c.name)}, today - ask your teacher for today's code</span></div>
      <form class="codeform" data-c="${c.id}"><input class="code-in" inputmode="numeric" maxlength="6" placeholder="6-digit code" required><button class="btn">Mark myself present</button></form>
      <p class="loc-msg" data-loc="${c.id}"></p></div>`;
  }).join("");

  let A = 0, T = 0;
  const rows = S.courses.map(c => {
    let a = 0, t = 0;
    for (const k in S.marks) { const [cid, , sid] = k.split("|"); if (+cid === c.id && +sid === s.id) { t++; if (S.marks[k] !== "A") a++; } }
    A += a; T += t;
    const p = t ? Math.round(100 * a / t) : null;
    return `<tr><td>${esc(c.code)}</td><td>${a} of ${t}</td><td class="${p !== null && p < S.threshold ? "lowtxt" : ""}">${p === null ? "no classes yet" : p + "%"}</td></tr>`;
  }).join("");
  const all = T ? Math.round(100 * A / T) : null;
  $("#s-history").innerHTML = `<p class="today-line" style="font-size:18px">Overall: ${all === null ? "no records yet" : `<b class="${all < S.threshold ? "lowtxt" : ""}">${all}%</b> (minimum is ${S.threshold}%)`}</p>
    <table class="hist"><tr><th>Course</th><th>Attended</th><th>Percentage</th></tr>${rows}</table>`;
}
$("#s-today").addEventListener("submit", e => {
  const form = e.target.closest(".codeform"); if (!form) return;
  e.preventDefault();
  const cid = +form.dataset.c, s = S.students.find(x => x.id === sess.id);
  const open = activeSession(cid, todayIso), typed = form.querySelector(".code-in").value.trim();
  const msg = document.querySelector(`[data-loc="${cid}"]`);
  if (!open || typed !== open.code) { msg.textContent = "That code is wrong or has expired. Check with your teacher."; msg.className = "loc-msg bad"; return; }
  const key = mk(cid, todayIso, s.id);
  const finish = () => { S.marks[key] = "P"; S.selfMarked[key] = true; save(); renderStudent(); say("Marked. Thank you."); };
  if (!S.security.requireLocation) { finish(); return; }
  if (!S.security.campus) { msg.textContent = "Location check is on, but the campus location isn't set yet. Ask your teacher."; msg.className = "loc-msg bad"; return; }
  if (!navigator.geolocation) { msg.textContent = "Your browser can't check location, so this device can't self-mark. Ask your teacher to mark you."; msg.className = "loc-msg bad"; return; }
  msg.textContent = "Checking your location..."; msg.className = "loc-msg";
  navigator.geolocation.getCurrentPosition(
    pos => {
      const d = Math.round(distMeters(S.security.campus, {lat: pos.coords.latitude, lng: pos.coords.longitude}));
      if (d <= S.security.radius) finish();
      else { msg.textContent = `You appear to be about ${d}m from campus, which is outside the allowed ${S.security.radius}m. Not marked.`; msg.className = "loc-msg bad"; }
    },
    () => { msg.textContent = "Location permission was denied, so attendance can't be self-marked from this device. Ask your teacher to mark you."; msg.className = "loc-msg bad"; },
    {enableHighAccuracy: true, timeout: 8000});
});

// ---------------- teacher register ----------------
function classDays() {
  const [y, m] = month.split("-").map(Number), n = new Date(y, m, 0).getDate(), out = [];
  for (let d = 1; d <= n; d++) { const dt = new Date(y, m - 1, d); if (course().days.includes(dt.getDay())) out.push(dt); }
  return out;
}
function summary() {
  $("#sum").innerHTML = S.courses.map(c => {
    let a = 0, t = 0;
    for (const k in S.marks) if (k.startsWith(c.id + "|")) { t++; if (S.marks[k] !== "A") a++; }
    const p = t ? Math.round(100 * a / t) : 0;
    return `<span class="chip"><b>${esc(c.code)}</b> ${p}% overall<i style="--w:${p}%"></i></span>`;
  }).join("");
}
function render() {
  const ds = classDays(), th = S.threshold;
  $("#th").value = th; $("#month").value = month; summary(); renderSession();
  $("#tabs").innerHTML = S.courses.map(c =>
    `<button role="tab" aria-selected="${c.id === courseId}" data-c="${c.id}"><b>${esc(c.code)}</b><span>${esc(c.name)}: ${c.days.map(d => DAYNAME[d]).join(", ")}</span></button>`).join("");

  const stats = S.students.map(s => {
    let a = 0, t = 0;
    for (const d of ds) { const v = S.marks[mk(courseId, iso(d), s.id)]; if (v) { t++; if (v !== "A") a++; } }
    return {s, p: t ? Math.round(100 * a / t) : null};
  });

  const marked = ds.filter(d => S.students.some(s => S.marks[mk(courseId, iso(d), s.id)]));
  const focus = ds.find(d => iso(d) === todayIso) || marked[marked.length - 1];
  if (focus) {
    const c = {P: 0, A: 0, L: 0}, f = iso(focus);
    S.students.forEach(s => { const v = S.marks[mk(courseId, f, s.id)]; if (v) c[v]++; });
    const label = focus.toLocaleDateString(undefined, {weekday: "long", day: "numeric", month: "long"});
    $("#line").innerHTML = `${label}: <span class="cnt P">${c.P} present</span>, <span class="cnt A">${c.A} absent</span>, <span class="cnt L">${c.L} on leave</span>.`;
  } else $("#line").textContent = "No classes to show for this month.";
  const low = stats.filter(x => x.p !== null && x.p < th);
  $("#alert").innerHTML = low.length
    ? `Below ${th}% this month: ` + low.map(x => `<b>${esc(x.s.name.split(" ")[0])}</b> (${x.p}%)`).join(", ") + "."
    : `Everyone with recorded classes is at or above ${th}%.`;

  const rows = stats.filter(x => (x.s.name + x.s.roll).toLowerCase().includes(query));
  if (!ds.length || !rows.length) { $("#reg").innerHTML = `<div class="empty">${ds.length ? "No student matches your search." : "This course has no class days this month."}</div>`; return; }

  const head = ds.map(d => {
    const f = iso(d); let p = 0, t = 0;
    S.students.forEach(s => { const v = S.marks[mk(courseId, f, s.id)]; if (v) { t++; if (v !== "A") p++; } });
    return `<th class="day ${f === todayIso ? "today" : ""}"><button data-day="${f}" title="Mark everyone present on ${f}">${DAYNAME[d.getDay()]}<span class="d">${d.getDate()}</span><i style="--w:${t ? Math.round(100 * p / t) : 0}%"></i></button></th>`;
  }).join("");

  const body = rows.map(({s, p}) => {
    const isLow = p !== null && p < th;
    const cells = ds.map(d => {
      const f = iso(d), k = mk(courseId, f, s.id), v = S.marks[k] || "", fut = f > todayIso, self = S.selfMarked[k];
      const lab = {P: "present", A: "absent", L: "on leave", "": "not marked"}[v] + (self ? ", marked by the student" : "");
      return `<td><button class="m ${v} ${self ? "self" : ""}" data-k="${k}" ${fut ? "disabled" : ""} aria-label="${esc(s.name)}, ${f}: ${lab}">${v}</button></td>`;
    }).join("");
    return `<tr><th scope="row" class="who ${isLow ? "low" : ""}" style="--w:${p ?? 0}%"><span class="nm"><b><button class="lk" data-stu="${s.id}" title="Open report card">${esc(s.name)}</button></b><small>${esc(s.roll)}</small></span><span class="pc ${isLow ? "low" : ""}">${p === null ? "-" : p + "%"}</span><button class="rm" data-rm="${s.id}" aria-label="Remove ${esc(s.name)}">&times;</button></th>${cells}</tr>`;
  }).join("");

  $("#reg").innerHTML = `<table><thead><tr><th class="corner" scope="col"><span style="padding-left:10px;font-size:12px;color:var(--mut)">Student and attendance</span></th>${head}</tr></thead><tbody>${body}</tbody></table>`;
  if (lastKey) { const el = document.querySelector(`[data-k="${lastKey}"]`); if (el) el.focus(); }
}

function renderSession() {
  const c = course(), heldToday = c.days.includes(today.getDay());
  if (!heldToday) { $("#sess").innerHTML = `<p class="sess-off">${esc(c.code)} has no class today, so there is nothing to check students into right now.</p>`; return; }
  const open = activeSession(c.id, todayIso);
  if (open) {
    const left = Math.max(0, open.expires - Date.now()), mm = Math.floor(left / 60000), ss = Math.floor(left / 1000) % 60;
    $("#sess").innerHTML = `<div class="sess-on"><div><span class="sess-label">Today's check-in code for ${esc(c.code)}</span><span class="sess-code">${open.code}</span></div>
      <div><span class="sess-timer">expires in ${mm}:${String(ss).padStart(2, "0")}</span>
      <button class="btn ghost" id="sess-new">New code</button><button class="btn ghost" id="sess-stop">Stop</button></div></div>`;
  } else {
    $("#sess").innerHTML = `<div class="sess-off"><span>Start check-in so students in class can mark themselves present for ${esc(c.code)}.</span><button class="btn" id="sess-start">Start attendance session</button></div>`;
  }
}
$("#sess").addEventListener("click", e => {
  const c = course();
  if (e.target.closest("#sess-start") || e.target.closest("#sess-new")) { startSession(c.id, todayIso); renderSession(); say("Check-in code ready. Read it out or display it for the class."); }
  else if (e.target.closest("#sess-stop")) { if (confirm("Stop check-in? Students will no longer be able to self-mark.")) { stopSession(c.id, todayIso); renderSession(); say("Check-in stopped."); } }
});
setInterval(() => { if (sess && sess.type === "staff" && !$("#teacher-view").hidden) renderSession(); }, 1000);

// ---- security settings dialog ----
$("#settings-btn").addEventListener("click", () => {
  $("#req-loc").checked = S.security.requireLocation;
  $("#radius").value = S.security.radius;
  $("#campus-status").textContent = S.security.campus ? "Campus location is set." : "Campus location is not set yet.";
  $("#settings").showModal();
});
$("#req-loc").addEventListener("change", e => { S.security.requireLocation = e.target.checked; save(); });
$("#radius").addEventListener("change", e => { S.security.radius = Math.max(20, +e.target.value || 200); save(); });
$("#set-campus").addEventListener("click", () => {
  if (!navigator.geolocation) { $("#campus-status").textContent = "This browser can't read location."; return; }
  $("#campus-status").textContent = "Reading this device's location...";
  navigator.geolocation.getCurrentPosition(
    pos => { S.security.campus = {lat: pos.coords.latitude, lng: pos.coords.longitude}; save(); $("#campus-status").textContent = "Campus location saved from this device."; },
    () => { $("#campus-status").textContent = "Location permission was denied."; });
});

$("#reg").addEventListener("click", e => {
  const cell = e.target.closest("[data-k]"), day = e.target.closest("[data-day]"), rm = e.target.closest("[data-rm]"), stu = e.target.closest("[data-stu]");
  if (stu) { openCard(+stu.dataset.stu); }
  else if (cell) {
    const k = cell.dataset.k, order = ["", "P", "A", "L"], cur = S.marks[k] || "", next = order[(order.indexOf(cur) + 1) % 4];
    next ? S.marks[k] = next : delete S.marks[k];
    delete S.selfMarked[k];                              // a teacher's own click always overrides the student flag
    lastKey = k; save(); render();
  } else if (day) {
    S.students.forEach(s => { const k = mk(courseId, day.dataset.day, s.id); S.marks[k] = "P"; delete S.selfMarked[k]; });
    lastKey = null; save(); render(); say(`Marked everyone present on ${day.dataset.day}.`);
  } else if (rm) {
    if (sess.role !== "admin") { say("Only an admin can remove a student."); return; }
    const s = S.students.find(x => x.id === +rm.dataset.rm);
    if (s && confirm(`Remove ${s.name} and their attendance records?`)) {
      S.students = S.students.filter(x => x.id !== s.id);
      Object.keys(S.marks).forEach(k => { if (k.endsWith("|" + s.id)) { delete S.marks[k]; delete S.selfMarked[k]; } });
      lastKey = null; save(); render(); say(`${s.name} removed.`);
    }
  }
});
$("#tabs").addEventListener("click", e => { const b = e.target.closest("[data-c]"); if (b) { courseId = +b.dataset.c; lastKey = null; render(); } });
$("#month").addEventListener("change", e => { if (e.target.value) { month = e.target.value; lastKey = null; render(); } });
$("#q").addEventListener("input", e => { query = e.target.value.trim().toLowerCase(); lastKey = null; render(); });
$("#th").addEventListener("change", e => { S.threshold = Math.min(100, Math.max(0, +e.target.value || 75)); save(); render(); });
$("#add").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("#nn").value.trim(); if (!name) return;
  const roll = $("#nr").value.trim() || "CS" + pad(S.nextId);
  if (S.students.some(s => s.roll.toLowerCase() === roll.toLowerCase())) { say(`Roll number ${roll} is already used. Choose another.`); return; }
  S.students.push({id: S.nextId++, roll, name, password: roll.toLowerCase()}); save(); $("#add").reset(); render();
  say(`${name} added. Their login is roll ${roll}, password ${roll.toLowerCase()}.`);
});
$("#reset").addEventListener("click", () => {
  if (confirm("Replace everything with the demo data?")) { S = seed(); save(); courseId = S.courses[0].id; lastKey = null; render(); say("Demo data restored."); }
});
$("#csv").addEventListener("click", () => {
  const ds = classDays(), q = v => `"${String(v).replace(/"/g, '""')}"`;
  const lines = [["Roll", "Name", ...ds.map(iso), "Attendance %"].map(q).join(",")];
  S.students.forEach(s => {
    let a = 0, t = 0;
    const cells = ds.map(d => { const v = S.marks[mk(courseId, iso(d), s.id)] || ""; if (v) { t++; if (v !== "A") a++; } return v; });
    lines.push([s.roll, s.name, ...cells, t ? Math.round(100 * a / t) : ""].map(q).join(","));
  });
  const url = URL.createObjectURL(new Blob([lines.join("\n")], {type: "text/csv"}));
  const a = Object.assign(document.createElement("a"), {href: url, download: `attendance-${course().code}-${month}.csv`});
  a.click(); URL.revokeObjectURL(url); say("CSV downloaded.");
});
$("#print").addEventListener("click", () => window.print());
$("#backup").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([JSON.stringify(S, null, 2)], {type: "application/json"}));
  const a = Object.assign(document.createElement("a"), {href: url, download: "smartattend-backup.json"});
  a.click(); URL.revokeObjectURL(url); say("Backup downloaded.");
});
$("#restore").addEventListener("change", e => {
  const f = e.target.files[0]; if (!f) return;
  f.text().then(t => {
    const d = JSON.parse(t);
    if (!Array.isArray(d.students) || !Array.isArray(d.courses) || !d.courses.length || typeof d.marks !== "object") throw 0;
    S = d; S.threshold = S.threshold || 75; S.selfMarked = S.selfMarked || {};
    S.staff = S.staff || seed().staff; S.nextId = S.nextId || Math.max(0, ...S.students.map(x => x.id)) + 1;
    S.sessions = S.sessions || {}; S.security = S.security || {requireLocation: false, campus: null, radius: 200};
    courseId = S.courses[0].id; save(); render(); say("Backup restored.");
  }).catch(() => say("That file is not a valid SmartAttend backup.")).finally(() => { e.target.value = ""; });
});

function openCard(id) {
  const s = S.students.find(x => x.id === id); if (!s) return;
  let A = 0, T = 0;
  const rows = S.courses.map(c => {
    let a = 0, t = 0; const ab = [];
    for (const k in S.marks) {
      const [cid, d, sid] = k.split("|");
      if (+cid === c.id && +sid === id) { t++; if (S.marks[k] === "A") ab.push(d); else a++; }
    }
    A += a; T += t;
    const p = t ? Math.round(100 * a / t) : null;
    return `<tr><td>${esc(c.code)}</td><td>${a} of ${t}</td><td class="${p !== null && p < S.threshold ? "lowtxt" : ""}">${p === null ? "-" : p + "%"}</td><td>${ab.sort().slice(-2).join(", ") || "none"}</td></tr>`;
  }).join("");
  const all = T ? Math.round(100 * A / T) : null;
  $("#card-body").innerHTML = `<h2>${esc(s.name)}</h2><p>${esc(s.roll)}, ${all === null ? "no records yet" : `overall attendance <b class="${all < S.threshold ? "lowtxt" : ""}">${all}%</b>`}</p>
    <table><tr><th>Course</th><th>Attended</th><th>%</th><th>Latest absences</th></tr>${rows}</table>`;
  $("#card").showModal();
}

showApp();
