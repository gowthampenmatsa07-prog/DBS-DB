# SmartAttend - Class register (HTML, CSS, JavaScript)

Three files, no installs, no server:

| File | Language | What it does |
|---|---|---|
| `index.html` | HTML | Page structure: header, course tabs, register table, add-student form |
| `style.css` | CSS | Look and feel, colours, dark mode, sticky name column |
| `script.js` | JavaScript | Data, marking logic, percentages, search, CSV export |

## Run it in VS Code
1. **File > Open Folder** and select this folder.
2. Install the **Live Server** extension, right-click `index.html`, choose **Open with Live Server**.
   (Double-clicking `index.html` also works.)

## Logging in
Two kinds of login, on the same page:
- **Student:** roll number + password. Demo: roll `CS01`, password `cs01` (each student's password
  is their roll number in lowercase).
- **Teacher / Admin:** `teacher / teacher123` or `admin / admin123`.

## Keeping self check-in to students who are actually in class
A student can only mark themselves present while the teacher's class session is open, and a fresh
6-digit code is required each time:

1. The teacher opens the course tab and clicks **Start attendance session**. A code appears in large
   text, valid for 10 minutes, with a countdown.
2. The teacher reads the code aloud or displays it on the classroom screen.
3. A student can now type that code on their own device to mark themselves present. A wrong or
   expired code is rejected. Nobody outside the room knows the code.
4. The teacher clicks **Stop** to close the session early, for example once the class has settled.

**Optional second layer - location check.** Click **Attendance security** in the teacher view to turn
on "Require students to be near campus". Click **Set this device's location as campus** once, from
inside the classroom or on campus, to save that spot. After that, a student's device also has to
report a location within the chosen radius (default 200m) before they can self-mark, using the
browser's own location permission. If a student denies location access, or is too far away, they
are told so and are not marked; the teacher can still mark them manually in the register.

A box a student marked themselves gets a small blue outline in the teacher's register, so the
teacher can see who checked in on their own versus who they marked by hand.

**Being upfront about the limits.** This runs entirely in the browser, with no server, so a
technically determined student could still fake their device's reported location. The code
requirement is the stronger control, since it can only be learned by being in the room (or being
told by someone who was). For a deployment that must resist GPS spoofing, the next step is to
verify location and the code on a server instead of in the browser - see the note in
`REVIEW_GUIDE.md`.

## Use it (teacher view)
- Click a course tab, then click a box to cycle Present, Absent, Leave, blank.
- Click a date to mark everyone present. Percentages update instantly.
- Add or remove students, search, change the minimum percentage, export CSV.
- Data is saved in your browser (localStorage). "Reset demo data" restores the sample class.

## Where things are in script.js
`seed()` demo data, `load()` and `save()` storage, `render()` draws the register,
the click handlers at the bottom do the marking.

## Extra features
- **Report card:** click any student's name to see attendance per course and their latest absences.
- **Course summary:** the chips at the top show overall attendance for each course.
- **Print report:** prints the register on paper or saves it as a PDF.
- **Backup / Restore:** download all data as a JSON file and load it back later.

See `REVIEW_GUIDE.md` for the demo script and viva answers.
